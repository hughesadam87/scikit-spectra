from pyuvapi import cmget, get_exampledata

df=get_exampledata()
print df